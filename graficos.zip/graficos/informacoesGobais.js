const url = 'https://raw.githubusercontent.com/guilhermeonrails/api/main/dados-globais.json'

async function visualizarInformacoesGlobais() {

}

async function visualizarInformacoesGlobais() {

        const res = await fetch(url)

    }
    visualizarInformacoesGlobais()
